# Inspector DroneProof DJI SDK Android Starter

This is the native Android companion starter for Inspector DroneProof. It is designed to receive a DroneProof mission export, show the waypoint plan, run a pilot safety gate, and provide the bridge point for DJI Mobile SDK wiring.

## What this package does

- Loads `droneproof-mission.json` from app assets.
- Parses DroneProof waypoints, altitude, heading, camera pitch, and target roof plane.
- Displays a pilot checklist and blocks flight start until the checks are acknowledged.
- Provides `DjiSdkBridge.kt` as the integration boundary for DJI Mobile SDK.
- Includes `DjiSdkRealAdapter.kt.example` to show where official DJI SDK calls should go.

## What this package does not do yet

- It does not include DJI's SDK binaries.
- It does not arm, launch, or command an aircraft until DJI SDK registration, aircraft connection, mission upload, and field testing are completed.
- It does not replace the pilot's FAA, airspace, VLOS, weather, obstacle, battery, or return-to-home checks.

## DJI setup required

DJI's official docs require a DJI Developer account, an App Key, and a matching Android package name. DJI's Android sample setup also places the App Key in the `com.dji.sdk.API_KEY` AndroidManifest metadata field before compiling and testing with a real controller/aircraft.

Package name in this starter:

```text
com.inspectorroofing.droneproofpilot
```

Google Play Console app record:

```text
App name: Inspector DroneProof Pilot
App ID: 4972784307494654443
Package: com.inspectorroofing.droneproofpilot
```

Set your key in Android Studio/Gradle:

```bash
./gradlew assembleDebug -PDJI_API_KEY=YOUR_DJI_APP_KEY
```

Or add this to a local, uncommitted `local.properties` file in this project folder:

```text
DJI_API_KEY=YOUR_DJI_APP_KEY
```

This project is configured to read `DJI_API_KEY` from `local.properties` first, then from Gradle properties. Keep `local.properties` private and do not upload it to WordPress or GitHub.

## Build

1. Open this folder in Android Studio.
2. Let Android Studio sync Gradle.
3. Add DJI Mobile SDK per the current official DJI instructions for your aircraft and controller.
4. Paste or provide your DJI App Key for package `com.inspectorroofing.droneproofpilot`.
5. Build `app`.
6. Test first with simulator/dry-run mode, then with props removed, then in a controlled field test.

## Mission flow

1. Generate mission in the WordPress DroneProof console.
2. Export `droneproof-mission.json`.
3. Put the mission in `app/src/main/assets/droneproof-mission.json` or wire file import/share intent later.
4. Open app.
5. Review waypoints.
6. Run Pilot QA.
7. Use the DJI bridge only after the official SDK adapter is implemented and verified.

## Source references

- DJI Mobile SDK documentation: https://developer.dji.com/mobile-sdk/documentation/introduction/index.html
- DJI sample/app-key setup: https://developer.dji.com/mobile-sdk/documentation/quick-start/index.html
