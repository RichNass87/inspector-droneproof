import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val localProperties = Properties().apply {
    val localFile = rootProject.file("local.properties")
    if (localFile.exists()) {
        localFile.inputStream().use { load(it) }
    }
}

fun stringProperty(name: String): String {
    return (project.findProperty(name) as String?)
        ?: localProperties.getProperty(name)
        ?: ""
}

android {
    namespace = "com.inspectorroofing.droneproofpilot"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.inspectorroofing.droneproofpilot"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"

        manifestPlaceholders["DJI_API_KEY"] = stringProperty("DJI_API_KEY")
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")

    // Add DJI Mobile SDK here using the current official DJI instructions for your aircraft.
    // Keep DjiSdkBridge as the boundary so the UI and mission parser stay testable.
}
