package com.inspectorroofing.droneproofpilot

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var statusView: TextView
    private lateinit var missionView: TextView
    private lateinit var bridge: DjiSdkBridge
    private lateinit var mission: DroneProofMission

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bridge = DjiSdkBridge(this)
        mission = loadMission()
        setContentView(buildContent())
        renderMission()
        renderStatus(bridge.registerSdk())
    }

    private fun buildContent(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }

        val title = TextView(this).apply {
            text = "Inspector DroneProof Pilot"
            textSize = 26f
            setTextColor(0xff071827.toInt())
        }

        statusView = TextView(this).apply {
            textSize = 16f
            setPadding(0, 20, 0, 20)
            setTextColor(0xff526377.toInt())
        }

        missionView = TextView(this).apply {
            textSize = 15f
            setTextColor(0xff071827.toInt())
        }

        val qaButton = Button(this).apply {
            text = "Run Pilot QA"
            setOnClickListener { renderStatus(bridge.prepareMission(mission)) }
        }

        val startButton = Button(this).apply {
            text = "Start Mission - Locked"
            setOnClickListener { renderStatus(bridge.startMissionLocked()) }
        }

        root.addView(title)
        root.addView(statusView)
        root.addView(qaButton)
        root.addView(startButton)
        root.addView(missionView)

        return ScrollView(this).apply { addView(root) }
    }

    private fun loadMission(): DroneProofMission {
        val json = assets.open("droneproof-mission.json")
            .bufferedReader()
            .use { it.readText() }
        return DroneProofMissionParser.parse(json)
    }

    private fun renderMission() {
        val waypointText = mission.waypoints.joinToString(separator = "\n\n") { waypoint ->
            "${waypoint.id} - ${waypoint.action}\n" +
                "Plane ${waypoint.targetPlane} | ${waypoint.altitudeFt.toInt()} ft | camera ${waypoint.cameraPitchDeg.toInt()} deg | heading ${waypoint.headingDeg.toInt()} deg\n" +
                waypoint.capture
        }
        missionView.text =
            "Mission: ${mission.missionId}\n" +
            "Address: ${mission.address}\n" +
            "Drone: ${mission.drone}\n" +
            "GPS lock: ${if (mission.hasGpsLock) "Yes" else "No - planning only"}\n\n" +
            waypointText
    }

    private fun renderStatus(status: DjiBridgeStatus) {
        statusView.text = "${status.title}\n${status.detail}"
        statusView.setTextColor(if (status.ok) 0xff0f75bc.toInt() else 0xffed1b24.toInt())
    }
}
